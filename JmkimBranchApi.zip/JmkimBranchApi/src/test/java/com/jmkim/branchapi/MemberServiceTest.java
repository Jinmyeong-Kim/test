package com.jmkim.branchapi;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.jmkim.branchapi.dao.MemberMapper;
import com.jmkim.branchapi.service.MemberService;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
class MemberServiceTest {
	
	@Autowired
	MemberMapper memberMapper;
	
	@Autowired
	MemberService memberService;
	
	/* 1번 문제 관련 테스트
	  * Q : 연도별 거래금액이 가장 많은 회원의 정보를 한명씩 출력
	  * 해결 프로세스 : 
	  *  연도별 계좌별로 취소거래가 아닌 거래건에 대하여 수수료 제외 금액을 합산하여 합산 거래금액이 최대인 고객의 정보 선출
	  */
	@Test
	public void selMaxAmtMemberByYear() throws Exception { // 1번 질문 테스트
		// given
		List<HashMap<String, Object>> maxMemList = memberService.selMaxAmtMemberByYear();
		HashMap<String, Object> params = new HashMap<String, Object>();
		
		// then
		// 2018년 테드, 2019년 에이스
		assertThat(maxMemList).isNotEmpty();
		assertThat(maxMemList.get(0)).containsKeys("year","name","acctNo","sumAmt");
		assertThat(maxMemList).extracting("year").isNotNull()
																	.contains("2018", "2019");
		assertThat(maxMemList.get(0).get("year")).isEqualTo("2018");
		assertThat(maxMemList.get(0).get("name")).isEqualTo("테드");
		assertThat(maxMemList.get(0).get("acctNo")).isEqualTo("11111114");
		assertThat(maxMemList.get(0).get("sumAmt")).isEqualTo(new BigDecimal(28992000));
		
		assertThat(maxMemList.get(1).get("year")).isEqualTo("2019");
		assertThat(maxMemList.get(1).get("name")).isEqualTo("에이스");
		assertThat(maxMemList.get(1).get("acctNo")).isEqualTo("11111112");
		assertThat(maxMemList.get(1).get("sumAmt")).isEqualTo(new BigDecimal(40998400));
		
		// when (18년에 로이에게 거금의 거래내역 성공 데이터 삽입) 
		params.put("regDt", "20181227");
		params.put("acctNo", "11111120");
		params.put("excgNum", 1);
		params.put("regId", "roy");
		params.put("amt", 90000000);
		params.put("fee", 900);
		params.put("cancleYn", "N");
		params.put("modId", "roy");
		memberService.insertStkExcgData(params);
		
		// then(18년에 로이가 거래금액 1등)
		maxMemList = memberService.selMaxAmtMemberByYear();
		assertThat(maxMemList.get(0).get("year")).isEqualTo("2018");
		assertThat(maxMemList.get(0).get("name")).isEqualTo("로이");
		assertThat(maxMemList.get(0).get("acctNo")).isEqualTo("11111120");
		
		// when(18년에 로이 1등 데이터 삭제 후) 
		memberService.delStkExcgData(params);
		
		// then(18년에 다시 테드 1등)
		maxMemList = memberService.selMaxAmtMemberByYear();
		assertThat(maxMemList.get(0).get("year")).isEqualTo("2018");
		assertThat(maxMemList.get(0).get("name")).isEqualTo("테드");
		assertThat(maxMemList.get(0).get("acctNo")).isEqualTo("11111114");
		
		// when(18년에 로이 거래 실패 데이터 삽입 후) 
		params.put("cancleYn", "Y");
		memberService.insertStkExcgData(params);
		
		// then (실패 데이터니 여전히 18년도 테드가 1등)
		maxMemList = memberService.selMaxAmtMemberByYear();
		assertThat(maxMemList.get(0).get("year")).isEqualTo("2018");
		assertThat(maxMemList.get(0).get("name")).isEqualTo("테드");
		assertThat(maxMemList.get(0).get("acctNo")).isEqualTo("11111114");
		
		// when (18년도 로이 거래 실패 데이터 삭제) 
		memberService.delStkExcgData(params);
		
		// then(18년에 다시 테드 1등)
		maxMemList = memberService.selMaxAmtMemberByYear();
		assertThat(maxMemList.get(0).get("year")).isEqualTo("2018");
		assertThat(maxMemList.get(0).get("name")).isEqualTo("테드");
		assertThat(maxMemList.get(0).get("acctNo")).isEqualTo("11111114");
		
		// when (19년에 리노에게 거금의 거래내역 성공 데이터 삽입) 
		params.put("regDt", "20191227");
		params.put("acctNo", "11111113");
		params.put("excgNum", 1);
		params.put("regId", "rino");
		params.put("amt", 90000000);
		params.put("fee", 900);
		params.put("cancleYn", "N");
		params.put("modId", "rino");
		memberService.insertStkExcgData(params);
		
		// then(19년에 리노 1등)
		maxMemList = memberService.selMaxAmtMemberByYear();
		assertThat(maxMemList.get(1).get("year")).isEqualTo("2019");
		assertThat(maxMemList.get(1).get("name")).isEqualTo("리노");
		assertThat(maxMemList.get(1).get("acctNo")).isEqualTo("11111113");
		
		// when(19년에 리노 1등 데이터 삭제) 
		memberService.delStkExcgData(params);
		
		// then (19년에 다시 에이스 1등)
		maxMemList = memberService.selMaxAmtMemberByYear();
		assertThat(maxMemList.get(1).get("year")).isEqualTo("2019");
		assertThat(maxMemList.get(1).get("name")).isEqualTo("에이스");
		assertThat(maxMemList.get(1).get("acctNo")).isEqualTo("11111112");
	}
	
	/* 2번 문제 관련 테스트
	  * Q : 2018년 또는 2019년에 거래가 없는 고객을 추출
	  * 해결 프로세스 : 
	  *  2-1) 전체 회원들의 회원별 18년도 거래수, 19년도 거래수를 구함.
	  *  2-2) 2-1의 회원들 중 18년도와 19년도 모두 거래한 고객을 제외시킴
	  *  2-3) 2-2의 데이터를 연도별로 정렬
	  */
	@Test
	public void selNoExchangeMember() throws Exception { // 2번 질문 테스트
		// given
		List<HashMap<String, Object>> noMemList = memberService.selNoExchangeMember();
		HashMap<String, Object> params = new HashMap<String, Object>();
		
		// then
		assertThat(noMemList).isNotEmpty();
		assertThat(noMemList.get(0)).containsKeys("year","name","acctNo");
		assertThat(noMemList).extracting("name").contains("사라","테드","제임스");
		assertThat(noMemList).extracting("year").contains("2018","2019");
		assertThat(noMemList).extracting("year", "name","acctNo")
										.contains(tuple("2018", "사라","11111115"),
													  tuple("2019", "테드","11111114"),
													  tuple("2018", "제임스","11111118"),
													  tuple("2019", "제임스","11111118")
													  );
		
		// when(18년도에 제임스 거래 내역 생성)
		params.put("regDt", "20181227");
		params.put("acctNo", "11111118");
		params.put("excgNum", 1);
		params.put("regId", "james");
		params.put("amt", 90000000);
		params.put("fee", 900);
		params.put("cancleYn", "N");
		params.put("modId", "roy");
		memberService.insertStkExcgData(params);
		
		// then
		assertThat(noMemList).isNotEmpty();
		assertThat(noMemList.get(0)).containsKeys("year","name","acctNo");
		assertThat(noMemList).extracting("name").contains("사라","테드","제임스");
		assertThat(noMemList).extracting("year").contains("2018","2019");
		assertThat(noMemList).extracting("year", "name","acctNo")
		.contains(tuple("2018", "사라","11111115"),
					  tuple("2019", "테드","11111114"),
					  tuple("2019", "제임스","11111118")
					  );
		
		// when(18년도 제임스 거래 데이터 삭제 후) 
		memberService.delStkExcgData(params);
		
		// then
		assertThat(noMemList).isNotEmpty();
		assertThat(noMemList.get(0)).containsKeys("year","name","acctNo");
		assertThat(noMemList).extracting("name").contains("사라","테드","제임스");
		assertThat(noMemList).extracting("year").contains("2018","2019");
		assertThat(noMemList).extracting("year", "name","acctNo")
										.contains(tuple("2018", "사라","11111115"),
													  tuple("2019", "테드","11111114"),
													  tuple("2018", "제임스","11111118"),
													  tuple("2019", "제임스","11111118")
													  );
		
		// when(18년도 사라 데이터 삽입)
		params.put("regDt", "20181227");
		params.put("acctNo", "11111115");
		params.put("excgNum", 1);
		params.put("regId", "sara");
		params.put("amt", 90000000);
		params.put("fee", 900);
		params.put("cancleYn", "N");
		params.put("modId", "sara");
		memberService.insertStkExcgData(params);
		
		// then
		assertThat(noMemList).isNotEmpty();
		assertThat(noMemList.get(0)).containsKeys("year","name","acctNo");
		assertThat(noMemList).extracting("name").contains("테드","제임스");
		assertThat(noMemList).extracting("year").contains("2018","2019");
		assertThat(noMemList).extracting("year", "name","acctNo")
										.contains(tuple("2019", "테드","11111114"),
													  tuple("2018", "제임스","11111118"),
													  tuple("2019", "제임스","11111118")
													  );
		
		// when(18년도 사라 데이터 삭제 후)
		memberService.delStkExcgData(params);
		
		// then
		assertThat(noMemList).isNotEmpty();
		assertThat(noMemList.get(0)).containsKeys("year","name","acctNo");
		assertThat(noMemList).extracting("name").contains("사라","테드","제임스");
		assertThat(noMemList).extracting("year").contains("2018","2019");
		assertThat(noMemList).extracting("year", "name","acctNo")
										.contains(tuple("2018", "사라","11111115"),
													  tuple("2019", "테드","11111114"),
													  tuple("2018", "제임스","11111118"),
													  tuple("2019", "제임스","11111118")
													  );
	}
}
