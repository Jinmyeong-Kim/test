package com.jmkim.branchapi;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.jmkim.branchapi.dao.BranchMapper;
import com.jmkim.branchapi.service.BranchService;
import com.jmkim.branchapi.service.MemberService;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
class BranchServiceTest {
	
	@Autowired
	BranchMapper branchMapper;
	
	@Autowired
	BranchService branchService;
	
	@Autowired
	MemberService memberService;
	
	/* 3번 문제 관련 테스트
	  * Q : 연도별 관리점별 거래금액 합계를 구하고 합계금액이 큰 순서로 출력
	  * 4번 문제에서 판교점의 경우 분당점과 통합되었다 했지만 
	  * 3번 문제에서는 판교점의 경우 순수 판교점 총 거래액을,
	  * 분당점의 경우 순수 분당점의 총 거래액을 뽑았습니다. 
	  * 해결 프로세스 : 
	  *  3-1) 조회기간에 속하는 연도별, 관리점별 거래금액과 해당 데이터가 속한 연도들을 리스트로 뽑음
	  *  3-2) 각 연도에 맞게 데이터를 연도별로 분리 후 
	  *  3-3) 분리한 데이터들을 연도순에 맞게 합침
	  *  
	  *  <3-1 예시 데이터>
	  *        연도    지점명   지점코드             금액             조회기간
	  *      2018	잠실점 	D		    14000000		2018,2019     --- row1
			  2019	판교점	    A			66795100		2018,2019     ----row2
		 	  
			  => <3-2 과정>
			        2018년도 데이터 : 2018	잠실점 데이터(row1)
			        2019년도 데이터 : 2019	판교점 데이터(row2)
			  => <3-3 과정>
			          연도별, 관리점별 리스트(2018년도 데이터, 2019년도 데이터) 
	  */
	@SuppressWarnings("unchecked")
	@Test
	public void test3_selBrnchAmtByYearDescAmt() throws Exception{ // 3번 질문 테스트
		// given
		LinkedList<HashMap<String, Object>> brnchAmtList = branchService.selBrnchAmtByYearDescAmt(); // 연도별, 거래금액별 지점 정보
		List<HashMap<String, Object>> amtTmp1 = (List<HashMap<String, Object>>) brnchAmtList.get(0).get("dataList");
		List<HashMap<String, Object>> amtTmp2 = (List<HashMap<String, Object>>) brnchAmtList.get(1).get("dataList");
		HashMap<String, Object> params = new HashMap<String, Object>();
		/*[{year=2018, 
		 * dataList=[{brName=분당점, brCode=B, sumAmt=38484000},
		 * 				 {brName=판교점, brCode=A, sumAmt=20505700},
		 * 				 {brName=강남점, brCode=C, sumAmt=20232867},
		 * 				 {brName=잠실점, brCode=D, sumAmt=14000000}]},
		 *  {year=2019, 
		 *  dataList=[{brName=판교점, brCode=A, sumAmt=66795100},
		 *  			  {brName=분당점, brCode=B, sumAmt=45396700},
		 *  			  {brName=강남점, brCode=C, sumAmt=19500000},
		 *  			 {brName=잠실점, brCode=D, sumAmt=6000000}]}]*/
		
		// then
		assertThat(brnchAmtList).isNotEmpty();
		assertThat(brnchAmtList).extracting("year").isNotNull()
																		.contains("2018", "2019");
		assertThat(brnchAmtList.get(0).get("year")).isNotNull()
																		.isEqualTo("2018");
		assertThat(brnchAmtList.get(1).get("year")).isNotNull()
																		.isEqualTo("2019");
		assertThat(amtTmp1.get(0).get("brName")).isNotNull()
																		.isEqualTo("분당점");
		assertThat(amtTmp1.get(3).get("brName")).isNotNull()
																		.isEqualTo("잠실점");
		
		// when(18년도에 제임스 거래 내역 생성)
		params.put("regDt", "20181227");
		params.put("acctNo", "11111118");
		params.put("excgNum", 1);
		params.put("regId", "james");
		params.put("amt", 90000000);
		params.put("fee", 900);
		params.put("cancleYn", "N");
		params.put("modId", "roy");
		memberService.insertStkExcgData(params);
		brnchAmtList = branchService.selBrnchAmtByYearDescAmt(); // 연도별, 거래금액별 지점 정보
		amtTmp1 = (List<HashMap<String, Object>>) brnchAmtList.get(0).get("dataList");
		
		// then (2018년 1등 잠실점, 2등 판교점, 3등 분당점, 4등 강남점)
		assertThat(brnchAmtList).isNotEmpty();
		assertThat(brnchAmtList).extracting("year").isNotNull()
																		.contains("2018", "2019");
		assertThat(brnchAmtList.get(0).get("year")).isNotNull()
																		.isEqualTo("2018");
		assertThat(brnchAmtList.get(1).get("year")).isNotNull()
																		.isEqualTo("2019");
		assertThat(amtTmp1.get(0).get("brName")).isNotNull()
																		.isEqualTo("잠실점");
		assertThat(amtTmp1.get(3).get("brName")).isNotNull()
																		.isEqualTo("강남점");
		
		// when
		memberService.delStkExcgData(params);
		brnchAmtList = branchService.selBrnchAmtByYearDescAmt(); // 연도별, 거래금액별 지점 정보
		amtTmp1 = (List<HashMap<String, Object>>) brnchAmtList.get(0).get("dataList");
		
		// then (다시 2018년 1등 분당점)
		assertThat(amtTmp1.get(0).get("brName")).isNotNull()
																		.isEqualTo("분당점");
		assertThat(amtTmp1.get(3).get("brName")).isNotNull()
																		.isEqualTo("잠실점");
		
		// when(19년도 사라 데이터 삽입)
		params.put("regDt", "20191227");
		params.put("acctNo", "11111115");
		params.put("excgNum", 1);
		params.put("regId", "sara");
		params.put("amt", 90000000);
		params.put("fee", 900);
		params.put("cancleYn", "N");
		params.put("modId", "sara");
		memberService.insertStkExcgData(params);
		brnchAmtList = branchService.selBrnchAmtByYearDescAmt();
		amtTmp2 = (List<HashMap<String, Object>>) brnchAmtList.get(1).get("dataList");
		
		// then(2019년 분당점 1등)
		assertThat(amtTmp2.get(0).get("brName")).isNotNull()
																		.isEqualTo("분당점");
		assertThat(amtTmp2.get(3).get("brName")).isNotNull()
																		.isEqualTo("잠실점");
		
		// when(2019년 분당점 1등)
		memberService.delStkExcgData(params);
		brnchAmtList = branchService.selBrnchAmtByYearDescAmt();
		amtTmp2 = (List<HashMap<String, Object>>) brnchAmtList.get(1).get("dataList");
		
		// then
		assertThat(amtTmp2.get(0).get("brName")).isNotNull()
																		.isEqualTo("판교점");
		assertThat(amtTmp2.get(3).get("brName")).isNotNull()
																		.isEqualTo("잠실점");
	}
	
	
	 /* 4번 문제 관련 테스트
	  * Q : 지점명을 받으면 해당 지점의 거래금액 합계를 출력
	  * 해결 프로세스 : 
	  *  4-1) 사용자로부터 지점명을 받으면 해당 지점에 대한 지점코드 및 이관 코드를 가져옴 : test4_selBrnchTTLBrCd()
	  *  4-2) 4-1에서 얻은 정보를 통해 해당 지점의 거래금액 산출 시 관리지점의 총 거래금액과 합쳐서 산출 : test4_selBrnchAmt()
	  */
	@Test
	public void test4_selBrnchTTLBrCd() throws Exception{ // 영업중인 지점의 지점코드 및 관리코드 정보(위의 4-1 프로세스)
		// given
		HashMap<String, Object> brnchInfo = new HashMap<String, Object>(); // 지점정보
		
		// when '판교' 검색
		brnchInfo = branchMapper.selBrnchTTLBrCd("판교");
		//then
		assertThat(brnchInfo)
			.as("판교점이 아닌 판교라는 부정확한 지점명으로 미검색")
			.isNull();
		
		// when '분당점' 검색
		brnchInfo = branchMapper.selBrnchTTLBrCd("분당점"); // 폐점처리
		// then
		assertThat(brnchInfo)
			.as("분당점은 폐점처리가 되어 미검색")
			.isNull();
		
		// when '잠실점' 검색
		brnchInfo = branchMapper.selBrnchTTLBrCd("잠실점"); // brnchInfo = {brCode=D, ttlBrCode=D}
		// then
		assertThat(brnchInfo).isNotEmpty();
		assertThat(brnchInfo).isNotNull();
		assertThat(brnchInfo.get("brCode")).isEqualTo("D");
		assertThat(brnchInfo.get("ttlBrCode"))
			.as("잠실점 brCode(지점코드) : D, ttlBrCode(지점코드 + 관리코드) : D(관리 처리된 지점이 없음)")
			.isEqualTo("D");
		
		// when '강남점' 검색
		brnchInfo = branchMapper.selBrnchTTLBrCd("강남점"); // brnchInfo = {brCode=C, ttlBrCode=C}
		// then
		assertThat(brnchInfo).isNotEmpty();
		assertThat(brnchInfo).isNotNull();
		assertThat(brnchInfo.get("brCode")).isEqualTo("C");
		assertThat(brnchInfo.get("ttlBrCode"))
			.as("강남점 brCode(지점코드) : C, ttlBrCode(지점코드 + 관리코드) : C (관리 처리된 지점이 없음)")
			.isEqualTo("C");
		
		// when '판교점' 검색
		brnchInfo = branchMapper.selBrnchTTLBrCd("판교점"); // brnchInfo = {brCode=A, ttlBrCode=A,B}
		// then
		assertThat(brnchInfo).isNotEmpty();
		assertThat(brnchInfo).isNotNull();
		assertThat(brnchInfo.get("brCode")).isEqualTo("A");
		assertThat(brnchInfo.get("ttlBrCode"))
			.as("판교점 brCode(지점코드) : A, ttlBrCode(지점코드 + 관리코드) : A,B (판교점은 분당점과 통폐합 되어 관리 처리됨)")
			.isEqualTo("A,B");
	}
	
	@Test
	public void test4_selBrnchAmt() throws Exception{ // 영업중인 지점의 총 거래금액을 가져옴(관리처리된 지점일 시 관리지점의 총액도 합산 / 위의 4-2 프로세스)
		// given
		HashMap<String, Object> brnchBrCdInfo = new HashMap<String, Object>(); // 4-1에서 나온 결과(영업중인 지점의 지점코드 및 관리코드 정보)
		HashMap<String, Object> brnchAmtInfo = new HashMap<String, Object>(); // 지점 총 거래금액
		HashMap<String, Object> params = new HashMap<String, Object>();
		
		// when (잠실점 총 거래금액)
		brnchBrCdInfo.put("brCode", "D"); // 지점코드
		brnchBrCdInfo.put("cdarr", new String[] {"D"}); // 지점 코드 및 지점이 관리하는 지점코드
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		BigDecimal expectedVal;
		expectedVal = new BigDecimal(20000000);
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("D");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("잠실점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when(잠실점에 데이터 삽입)
		params.put("regDt", "20181227");
		params.put("acctNo", "11111119");
		params.put("excgNum", 1);
		params.put("regId", "judy");
		params.put("amt", 20000000);
		params.put("fee", 0);
		params.put("cancleYn", "N");
		params.put("modId", "judy");
		memberService.insertStkExcgData(params);
		
		// then (잠실점 : 40000000)
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		assertThat(brnchAmtInfo).isNotNull();
		expectedVal = new BigDecimal(40000000);
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("D");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("잠실점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when(잠실점에 거래 실패 데이터 삽입)
		memberService.delStkExcgData(params);
		params.put("cancleYn", "Y");
		memberService.insertStkExcgData(params);
		
		// then(잠실점 그대로 20000000)
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		assertThat(brnchAmtInfo).isNotNull();
		expectedVal = new BigDecimal(20000000);
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("D");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("잠실점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		//when (강남점 총 거래금액)
		brnchBrCdInfo.put("brCode", "C");
		brnchBrCdInfo.put("cdarr", new String[] {"C"});
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		expectedVal = new BigDecimal(39732867);
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("C");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("강남점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when(순수 분당점 총 거래금액)
		brnchBrCdInfo.put("brCode", "B");
		brnchBrCdInfo.put("cdarr", new String[] {"B"});
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		expectedVal = new BigDecimal(83880700); // 분당점 총 거래금액
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("B");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("분당점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when 순수 판교점에서만 일어난 총 거래 금액, 분당점과 합산된 금액 아님
		brnchBrCdInfo.put("brCode", "A");
		brnchBrCdInfo.put("cdarr", new String[] {"A"});
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		expectedVal = new BigDecimal(87300800); // 순수 판교점 총 거래금액
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("A");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("판교점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when 판교점(분당점과 통합처리된 판교점 총 거래 금액)
		brnchBrCdInfo.put("brCode", "A");
		brnchBrCdInfo.put("cdarr", new String[] {"A", "B"}); // 분당점 + 판교점 통합처리
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		expectedVal = new BigDecimal(171181500); // 통합된 판교점 거래금액(판교점 87300800 + 분당점 83880700)
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("A");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("판교점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when 판교점(분당점, 강남점과 통합처리 되었다 가정)
		brnchBrCdInfo.put("brCode", "A");
		brnchBrCdInfo.put("cdarr", new String[] {"A", "B", "C"}); // 분당점 + 판교점 + 강남점 통합처리
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		expectedVal = new BigDecimal(210914367);  // 통합된 판교점 거래금액(판교점 87300800 + 분당점 83880700 + 강남점 39732867)
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("A");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("판교점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
		
		// when 잠실점(강남점과 통합처리 되었다 가정)
		brnchBrCdInfo.put("brCode", "D"); // 지점코드
		brnchBrCdInfo.put("cdarr", new String[] {"C","D"}); // 지점 코드 및 지점이 관리하는 지점코드
		brnchAmtInfo = branchService.selBrnchAmt(brnchBrCdInfo);
		expectedVal = new BigDecimal(59732867); // 20000000(잠실점) + 39732867(강남점)
		
		// then
		assertThat(brnchAmtInfo).isNotNull();
		assertThat(brnchAmtInfo.get("brCode")).isEqualTo("D");
		assertThat(brnchAmtInfo.get("brName")).isEqualTo("잠실점");
		assertThat(brnchAmtInfo.get("sumAmt")).isEqualTo(expectedVal);
	}
}
