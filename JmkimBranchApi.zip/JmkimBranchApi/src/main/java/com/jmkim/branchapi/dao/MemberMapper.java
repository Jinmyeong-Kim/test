package com.jmkim.branchapi.dao;

import java.util.HashMap;
import java.util.List;

public interface MemberMapper {
	public List<HashMap<String, Object>> selMaxAmtMemberByYear() throws Exception;
	public List<HashMap<String, Object>> selNoExchangeMember() throws Exception;
	public void insertStkExcgData(HashMap<String, Object> params) throws Exception;
	public void delStkExcgData(HashMap<String, Object> params) throws Exception;
}
