package com.jmkim.branchapi.dao;

import java.util.HashMap;
import java.util.LinkedList;

public interface BranchMapper {
	public LinkedList<HashMap<String, Object>> selBrnchAmtByYearDescAmt() throws Exception;
	public HashMap<String, Object> selBrnchTTLBrCd(String brName) throws Exception;
	public HashMap<String, Object> selBrnchAmt(HashMap<String, Object> brnchInfo) throws Exception;
}
