package com.jmkim.branchapi.controller;


import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice("com.jmkim.branchapi.controller")
public class ApiExceptionHandler {
	/*@ExceptionHandler(BranchNotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ResponseEntity<ApiErrorDetail> handlerUserNotFoundException(BranchNotFoundException brnf){
		return new ResponseEntity(errorDetail, HttpStatus.NOT_FOUND)
	}*/
	
	

}
