package com.jmkim.branchapi.service;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public interface MemberService {
	public List<HashMap<String, Object>> selMaxAmtMemberByYear() throws Exception; // 연도별 고객 거래금액 리스트
	public LinkedList<HashMap<String, Object>> selNoExchangeMember() throws Exception; // 미거래 고객 리스트
	public void insertStkExcgData(HashMap<String, Object> params) throws Exception; // 거래내역 데이터 삽입
	public void delStkExcgData(HashMap<String, Object> params) throws Exception; // 거래내역 데이터 삭제
}
