package com.jmkim.branchapi.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.jmkim.branchapi.dao.MemberMapper;
import com.jmkim.branchapi.service.MemberService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {
	
	private final MemberMapper memberMapper;
	
	@Override
	public List<HashMap<String, Object>> selMaxAmtMemberByYear() throws Exception{
		return memberMapper.selMaxAmtMemberByYear();
	}

	@Override
	public LinkedList<HashMap<String, Object>> selNoExchangeMember() throws Exception{
		List<HashMap<String, Object>> noMemListRaw = memberMapper.selNoExchangeMember();
		List<HashMap<String, Object>> noMemList2018 = new ArrayList<>(); // 2018 비거래 회원 리스트
		List<HashMap<String, Object>> noMemList2019 = new ArrayList<>(); // 2019 비거래 회원 리스트
		LinkedList<HashMap<String, Object>> noMemList = new LinkedList<HashMap<String, Object>>(); // 2018, 2019 비거래 회원 리스트
		
		for(HashMap<String, Object> n : noMemListRaw) {
			if(n.get("year").equals("2018")) {
				noMemList2018.add(n);
			}else {
				noMemList2019.add(n);
			}
		}
		
		noMemList.addAll(noMemList2018);
		noMemList.addAll(noMemList2019);
		
		return noMemList;
	}
	
	@Override
	public void insertStkExcgData(HashMap<String, Object> params) throws Exception{
		memberMapper.insertStkExcgData(params);
	}
	
	@Override
	public void delStkExcgData(HashMap<String, Object> params) throws Exception{
		memberMapper.delStkExcgData(params);
	}
}
